
/*
* Main BB3 application module
 */

(function () {
    "use strict";
    // this function is strict...
}());


var bb3App = angular.module('bb3', []);



