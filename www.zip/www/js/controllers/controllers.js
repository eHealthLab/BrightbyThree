

/**
 * Controller which manages the completion state of the navbar
 */

//var bb3App = angular.module('bb3', []);

bb3App.controller('stateController',
    function($scope, $window, $http, participantService) {

        /**
         * Initialize the controller
         */
        init();
        function init() {

            $scope.participantService = participantService;
            $scope.login = true;
            $scope.currentLanguage = "English";
            $scope.loginMinutesEnabled = false;
            $scope.badgesEnabled = false;
            $scope.goalsEnabled = false;
            $scope.networkStatsEnabled = false;
            $scope.goalshaveBeenSet = 0;
            $scope.goalsDaysPerWeek = participantService.getGoalsDays();
            $scope.goalsMinutesPerDay = participantService.getGoalsMinutes();
            $scope.newBadgeEarned = participantService.getEarnedNewBadge();
        }

        $scope.getLoginStatus = function() {
            window.loginStatus = $scope.login;
            //return $scope.login;
        };

        $scope.changeLoginStatus = function() {
            window.alert('called function');
            $scope.login = false;
        };

        $scope.earnedNewBadge = function () {
            return participantService.getEarnedNewBadge();
        };

        $scope.logout = function () {
            if (confirm('Are you sure you want to logout?')) {
                //$scope.loginSuccessful = false;
                $scope.login = false;
                window.alert($scope.login);
                //return $scope.login;
            }
        }
})

    .controller('dashboardController',
    function ($scope, $window, $http) {

        init();
        function init() {
            $scope.status = false;
        }

        $scope.getStatus = function() {

            $scope.$on("$includeContentLoaded", function(){
                $("#dashboard").trigger("create");
            });

            return $scope.status;
        };
    })

    .controller('personalInfoController',
    function ($scope, $window, $http, $location, $element) {
        init();
        function init() {

            $scope.newParticipant = {
                firstName: undefined,
                lastName: undefined,
                emailID: undefined,
                password1: undefined,
                password2: undefined,
                phoneNumber: undefined,
                zipcode: undefined,
                babyName: undefined,
                babyDOB: undefined,
                babyGender: undefined
            };

            $scope.loginSuccessful = true;

        }

        $scope.getBabyName = function() {
            $scope.newParticipant.babyName = "notDefault";
            return $scope.newParticipant.babyName;
        };

        $scope.submitSignupInfo = function() {
            window.alert('signup pressed');
            var email = $scope.newParticipant.emailID.toUpperCase();

            if($scope.newParticipant.password1 != $scope.newParticipant.password2) {
                //$scope.signUpErrorNotification = "Passwords do not match. Correct them and try again.";
                window.alert('Passwords do not match. Correct them and try again.');
            }

            $http({method: 'POST',
                url: 'http://brightbythree.org:3000/loginSignup/' +
                $scope.newParticipant.firstName + '/' +
                $scope.newParticipant.lastName + '/' +
                email + '/' +
                $scope.newParticipant.password1 + '/' +
                $scope.newParticipant.phoneNumber

                /*
                +
                $scope.newParticipant.babyName +
                $scope.newParticipant.babyDOB +
                $scope.newParticipant.babyGender +
                $scope.newParticipant.babyGender
                */
            }).
                success(function(data, status, headers, config) {
                    $scope.appsData = data;
                    if(data.status == "true") {
                        window.alert("You have successfully signed up. " +
                        "Please login to continue");
                        $location.path("/dashboard");
                    }
                    else {
                        window.alert("Email ID exists. Use a different Email ID.");
                    }
                }).
                error(function(data, status, headers, config) {
                    window.alert("Unable to contact server. Please try again later.");

                });


        };

        $scope.submitLoginInfo = function() {


            window.alert('inside login in button pressed');
            var email = $scope.emailID.toUpperCase();

                $http.get('http://brightbythree.org:3000/loginSignup/' + email + '/' + $scope.password1).
                    success(function (data, status, headers, config) {
                        $window.alert("values: " + email + $scope.password1);
                        $scope.appsData = data;
                        if ($scope.appsData != "false") {
                            window.alert('Login successful');
                            $scope.login = true;
                            $location.path("dashboard.html");
                            $scope.loginSucessful = true;
                            $scope.emailID = "";
                            $scope.password = "";
                            $location.path("/dashboard");
                        }
                        else {
                            $scope.loginErrorNotification = "check the info and login again.";
                            window.alert('Check the login information and try again.');
                        }
                    }).
                    error(function (data, status, headers, config) {
                        window.alert("sorry, error");
                        window.alert("Unable to contact server. Please try again later.");
                    });
        }


    })

    .controller('textMessageController',
    function ($scope, $window) {
        init();

        function init() {

            $scope.sampleTextSubject1 = "Welcome to CBB!";
            $scope.sampleTextContent1 = "Over the coming months you will be " +
            "receiving messages with ideas to promote your baby’s development.";
            $scope.sampleTextImage = "../images/BB3_logo_vert_rgb.png";
            $scope.sampleTextVideo1 = "https://www.youtube.com/embed/mN5rIVbUG7M";


            $scope.sampleTextSubject2 = "True or False?";
            $scope.sampleTextContent2 = "Babies are born with all of the " +
            "brain cells they need to learn to talk.";
            $scope.sampleTextImage2 = "../images/BB3_logo_vert_rgb.png";
            $scope.sampleTextVideo2 = "https://www.youtube.com/embed/mN5rIVbUG7M";

            $scope.sampleTextSubject3 = "Quiz Answer";
            $scope.sampleTextContent3 = "Correct! Babies are born with the brain cells they " +
            "need to learn to talk! Talking to your baby strengthens the connections these cells " +
            "need to survive.";
            $scope.sampleTextImage = "../images/BB3_logo_vert_rgb.png";
            $scope.sampleTextVideo3 = "https://www.youtube.com/embed/mN5rIVbUG7M";
        }

        $scope.addToFavoritesPressed = function(){
            window.alert('add to favorites pressed');
        };

        $scope.removeFromFavoritesPressed = function(){
            window.alert('remove from favorites pressed');
        };

        $scope.startCameraPressed = function(){
            window.alert('start camera pressed');
        };
    })


    .controller('badgesController',
    function ($scope, $window, participantService) {
        init();

        function init() {

            $scope.participantService = participantService;
            $scope.totalPoints = 0;
            $scope.participantID = undefined;
            $scope.status150 = true;
            $scope.status400 = true;
            $scope.status700 = false;
            $scope.status1000 = false;
            $scope.status1500 = false;
            $scope.status2000 = false;
            $scope.status2500 = false;
            $scope.status3000 = false;
            $scope.status3500 = false;
            $scope.status4000 = false;
            $scope.status4500 = false;
            $scope.status5000 = false;

        }

        $scope.getBadgeInformation = function () {
            //window.alert('badge information pressed');
            if ($scope.totalPoints >= 150 && $scope.totalPoints < 400) {
                $scope.status150 = true;
                participantService.setEarnedNewBadge(true);
                //$scope.newBadgeEarned = participantService.se
                window.alert('Congratulations! You just earned a new badge.')
                //return $scope.earnedNewBadge();
            }

            else if ($scope.totalPoints >= 400 && $scope.totalPoints < 700) {
                $scope.status400 = true;
            }

            else if ($scope.totalPoints >= 700 && $scope.totalPoints < 1000) {
                $scope.status700 = true;
            }

            else if ($scope.totalPoints >= 1000 && $scope.totalPoints < 1500) {
                $scope.status1000 = false;
            }

            else if ($scope.totalPoints >= 1500 && $scope.totalPoints < 2000) {
                $scope.status1500 = false;
            }

            else if ($scope.totalPoints >= 2000 && $scope.totalPoints < 2500) {
                $scope.status2000 = false;
            }

            else if ($scope.totalPoints >= 2500 && $scope.totalPoints < 3000) {
                $scope.status2500 = false;
            }

            else if ($scope.totalPoints >= 3000 && $scope.totalPoints < 3500) {
                $scope.status3000 = false;
            }

            else if ($scope.totalPoints >= 3500 && $scope.totalPoints < 4000) {
                $scope.status3500 = false;
            }

            else if ($scope.totalPoints >= 4000 && $scope.totalPoints < 4500) {
                $scope.status4000 = false;
            }

            else if ($scope.totalPoints >= 4500 && $scope.totalPoints < 5000) {
                $scope.status4500 = false;
            }

            else if ($scope.totalPoints >= 5000) {
                $scope.status5000 = false;
            }

        };

        $scope.updateBadgeInformation = function () {
            //window.alert('update badge information pressed');
        };

        $scope.updateBadgeNotification = function () {
            if (participantService.getEarnedNewBadge()) {
                //window.alert('yes, set. disabling now');
                participantService.setEarnedNewBadge(false);
                $scope.newBadgeEarned = false;
            }
        }

    })

    .controller('emailController',
    function ($scope, $window, $http) {
        init();

        function init() {

            $scope.feedbackText = undefined;

        }

        $scope.sendEmailForgotEmailID = function () {

            window.alert('forgot email id called');
            $window.plugin.email.open({
                to:      ['agileehealth@gmail.com'],
                subject: 'Forgot my email id',
                body:    'I have forgotten my email id. Please contact me at BLAH'
            });

        };

        $scope.sendEmailForgotPassword = function () {

            window.alert('forgot password called');
            $window.plugin.email.open({
                to:      ['agileehealth@gmail.com'],
                subject: 'Forgot my password',
                body:    'I have forgotten my password. ' +
                'Please contact me at BLAH'
            });

        };

        $scope.sendFeedback = function() {
            window.alert("inside feedback function" + $scope.feedbackText);
            if ($scope.feedbackText != undefined) {
                //if(participantService.getLoginStatus() != "false") {

                    $http({method: 'POST',
                        url: 'http://brightbythree.org:3000/feedback/' +
                        //url: 'http://mothersmilk.ucdenver.edu:3000/feedback/' +
                        $scope.feedbackText
                    }).
                    success(function(data, status, headers, config) {
                        $scope.appsData = data;
                        if(data == "Success") {
                            if ($scope.currentLanguage == "English") {
                                window.alert("Thank You! Your feedback has been submitted.");
                                $location.path("../pages/settings.html");
                            }
                            else if ($scope.currentLanguage == "Español") {
                                window.alert("¡Gracias! Sus comentarios fueron entregados.");
                                $location.path("../pages/settings.html");
                            }
                        }
                    }).
                    error(function(data, status, headers, config) {
                        if ($scope.currentLanguage == "English") {
                            window.alert("Unable to contact server. Please try again later.");
                        }
                        else if ($scope.currentLanguage == "Español") {
                            window.alert("No puede comunicarse con el servidor. Por favor de intentarlo más tarde. ");
                        }


                    });

                //}

                //else {
                    window.alert($scope.currentLanguage);
                    if ($scope.currentLanguage == "English") {
                        window.alert("Please login first.");
                        $location.path("/login");
                    }
                    else if ($scope.currentLanguage == "Español") {
                        window.alert("Por favor de hacer login primero.");
                        $location.path("/spanish/login");
                    }


               // }
            }
        }

    })

    .controller('goalsController',
    function ($scope, $window, $http, participantService) {
        init();

        function init() {

            $scope.participantService = participantService;
            $scope.goals =
            {
                daysPerWeek: 2,
                minutesPerDay: 10
            }
        }

        $scope.getGoalsInfo = function () {

            // Put a http call here to grab these values and then set these two.

            $scope.goals.daysPerWeek = 2;
            $scope.goals.minutesPerDay = 10;
            //return $scope.goals;

        };

        $scope.setGoals = function () {

            participantService.setGoalsDays($scope.goals.daysPerWeek);
            participantService.setGoalsMinutes($scope.goals.minutesPerDay);

            //window.alert('inside set goals function');

            // setup a http call to post these results back to goals table.

            //window.alert('inside set goals' + $scope.daysPerWeek + $scope.minutesPerDay);

        };

        $scope.resetGoals = function () {

            window.alert('called');
            if (confirm('Are you sure you want to reset your goals?')) {

                //window.alert('inside reset goals');
                $scope.goals.daysPerWeek = 0;
                $scope.goals.minutesPerDay = 0;


                // send a http request for this purpose. to udpate the table.
            }
        }

    })

    .controller('logMinutesController',
    function ($scope, $window, $http, $location, participantService) {
        init();

        function init() {

            $scope.participantService = participantService;
            $scope.logNumberOfMinutes = participantService.getLogMinutes();
        }

        $scope.logMinutes = function () {

            participantService.setLogMinutes($scope.logNumberOfMinutes);
            //window.alert('save minutes');

            //send an http request to badges table to update these minutes.

            window.alert('Great! Your minutes have been logged in');
            $location.path("/dashboard");

            //send http request to check the total points from badges.





        }

    })

;